#!/usr/bin/env bash

# List Agents in your tenant
cortex agents list


# List Skills in your tenant
cortex skills list


#List Datasets in your tenant
cortex datasets list
